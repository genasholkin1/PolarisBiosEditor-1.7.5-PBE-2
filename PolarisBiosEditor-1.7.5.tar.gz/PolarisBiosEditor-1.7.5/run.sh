#!/bin/bash
mono PolarisBiosEditor.exe
